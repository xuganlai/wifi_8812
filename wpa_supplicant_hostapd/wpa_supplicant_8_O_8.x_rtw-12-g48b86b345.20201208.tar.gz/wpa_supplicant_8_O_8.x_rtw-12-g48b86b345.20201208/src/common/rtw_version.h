#ifndef RTW_VERSION_H
	#define RTW_VERSION_H
	#define RTW_VERSION "rtw-12-g48b86b345.20201208"
#endif /* RTW_VERSION_H */
